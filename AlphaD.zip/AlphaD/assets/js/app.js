(function () {
  "use strict";

  const root = document.getElementById("view-root");
  const modalLayer = document.getElementById("modal-layer");
  const toastRegion = document.getElementById("toast-region");
  const nav = document.getElementById("primary-nav");
  const breadcrumb = document.getElementById("breadcrumb-current");
  const cart = new Map();
  const posState = { category: "ทั้งหมด", payment: "เงินสด", customer: "ลูกค้าทั่วไป" };
  const state = {
    page: "overview",
    orderFilter: "ทั้งหมด",
    orderChannel: "ทุกช่องทาง",
    customerLevel: "ทุกระดับสมาชิก",
    productFilter: "ทั้งหมด",
    inventoryFilter: "ทั้งหมด",
    reportRange: "7 วัน",
    chartRange: "สัปดาห์",
    settingsTab: "ข้อมูลร้าน",
    globalQuery: "",
    settings: { lowStock: true, dailySummary: true, sound: false }
  };

  const pageNames = {
    overview: "ภาพรวม",
    pos: "ขายหน้าร้าน",
    orders: "คำสั่งซื้อ",
    products: "สินค้าและเมนู",
    inventory: "สต็อกวัตถุดิบ",
    customers: "ลูกค้า",
    team: "ทีมงาน",
    reports: "รายงาน",
    settings: "ตั้งค่าร้าน"
  };

  const orders = [
    { id: "BM-2048", customer: "คุณมินตรา", items: "ลาเต้เย็น × 2, ครัวซองต์ × 1", time: "10:42", total: 265, channel: "หน้าร้าน", status: "กำลังทำ" },
    { id: "BM-2047", customer: "คุณธนา", items: "อเมริกาโน่ร้อน × 1", time: "10:36", total: 85, channel: "เดลิเวอรี", status: "รอรับ" },
    { id: "BM-2046", customer: "คุณพลอย", items: "Dirty × 1, เมล็ด House Blend × 1", time: "10:21", total: 415, channel: "หน้าร้าน", status: "เสร็จแล้ว" },
    { id: "BM-2045", customer: "คุณกิตติ", items: "คาปูชิโน่ × 2", time: "10:08", total: 220, channel: "เดลิเวอรี", status: "เสร็จแล้ว" },
    { id: "BM-2044", customer: "คุณอร", items: "มัทฉะลาเต้เย็น × 1", time: "09:54", total: 125, channel: "หน้าร้าน", status: "เสร็จแล้ว" },
    { id: "BM-2043", customer: "คุณวิน", items: "ฟิลเตอร์ประจำวัน × 1", time: "09:41", total: 145, channel: "เดลิเวอรี", status: "ยกเลิก" },
    { id: "BM-2042", customer: "คุณณิชา", items: "ลาเต้ร้อน × 1, บราวนี่ × 1", time: "09:28", total: 190, channel: "หน้าร้าน", status: "เสร็จแล้ว" }
  ];

  const products = [
    { id: "P-001", name: "ลาเต้เย็น", category: "กาแฟ", price: 120, cost: 37, stock: 34, unit: "แก้ว", status: "พร้อมขาย", emoji: "🥛", art: "art-orange", description: "เอสเปรสโซ่คู่ · นมสด · หวานน้อย" },
    { id: "P-002", name: "อเมริกาโน่", category: "กาแฟ", price: 90, cost: 24, stock: 42, unit: "แก้ว", status: "พร้อมขาย", emoji: "☕", art: "art-green", description: "เลือกได้ทั้งคั่วกลางและคั่วเข้ม" },
    { id: "P-003", name: "Dirty", category: "กาแฟ", price: 145, cost: 48, stock: 16, unit: "แก้ว", status: "พร้อมขาย", emoji: "🧋", art: "art-violet", description: "นมเย็นจัด · ช็อตเอสเปรสโซ่" },
    { id: "P-004", name: "มัทฉะลาเต้", category: "ชา", price: 135, cost: 53, stock: 11, unit: "แก้ว", status: "พร้อมขาย", emoji: "🍵", art: "art-green", description: "อูจิมัทฉะ · นมสด · เลือกระดับหวานได้" },
    { id: "P-005", name: "ครัวซองต์เนยสด", category: "เบเกอรี", price: 95, cost: 42, stock: 7, unit: "ชิ้น", status: "ใกล้หมด", emoji: "🥐", art: "art-orange", description: "อบสดทุกเช้า · เนยฝรั่งเศส" },
    { id: "P-006", name: "House Blend 250g", category: "เมล็ดกาแฟ", price: 420, cost: 226, stock: 3, unit: "ถุง", status: "ใกล้หมด", emoji: "🫘", art: "art-blue", description: "ช็อกโกแลต · คาราเมล · ถั่วคั่ว" },
    { id: "P-007", name: "บราวนี่ดาร์กช็อก", category: "เบเกอรี", price: 85, cost: 34, stock: 14, unit: "ชิ้น", status: "พร้อมขาย", emoji: "🍫", art: "art-violet", description: "ดาร์กช็อกโกแลต 70% · อบใหม่" },
    { id: "P-008", name: "ฟิลเตอร์ประจำวัน", category: "กาแฟ", price: 145, cost: 51, stock: 18, unit: "แก้ว", status: "พร้อมขาย", emoji: "🫖", art: "art-blue", description: "เมล็ดพิเศษหมุนเวียนตามฤดูกาล" }
  ];

  const inventory = [
    { id: "I-001", name: "เมล็ด House Blend", type: "เมล็ดกาแฟ", stock: 3, unit: "ถุง", par: 10, location: "ชั้นเมล็ดกาแฟ", status: "ใกล้หมด", emoji: "🫘" },
    { id: "I-002", name: "เมล็ด Single Origin", type: "เมล็ดกาแฟ", stock: 8, unit: "ถุง", par: 8, location: "ชั้นเมล็ดกาแฟ", status: "ปกติ", emoji: "🌱" },
    { id: "I-003", name: "นมสดพาสเจอร์ไรส์", type: "นมและทางเลือก", stock: 4, unit: "ขวด", par: 12, location: "ตู้เย็น A", status: "ใกล้หมด", emoji: "🥛" },
    { id: "I-004", name: "นมโอ๊ต", type: "นมและทางเลือก", stock: 9, unit: "กล่อง", par: 8, location: "ตู้เย็น A", status: "ปกติ", emoji: "🌾" },
    { id: "I-005", name: "แก้วเย็น 16 oz", type: "บรรจุภัณฑ์", stock: 68, unit: "ใบ", par: 50, location: "ชั้นเก็บของ", status: "ปกติ", emoji: "🥤" },
    { id: "I-006", name: "ครัวซองต์เนยสด", type: "เบเกอรี", stock: 7, unit: "ชิ้น", par: 15, location: "ตู้โชว์", status: "ใกล้หมด", emoji: "🥐" },
    { id: "I-007", name: "ไซรัปวานิลลา", type: "วัตถุดิบอื่น", stock: 0, unit: "ขวด", par: 3, location: "ชั้นบาร์", status: "หมด", emoji: "🍯" }
  ];

  const customers = [
    { name: "มินตรา วัฒนากุล", phone: "08x-xxx-2184", visits: 18, spent: 4260, points: 426, last: "วันนี้ 10:42", level: "เมล็ดทอง", initials: "ม", avatar: "" },
    { name: "ธนา ภูมิพัฒน์", phone: "09x-xxx-0531", visits: 12, spent: 2980, points: 298, last: "วันนี้ 10:36", level: "เมล็ดเขียว", initials: "ธ", avatar: "avatar-2" },
    { name: "พลอยไพลิน แสงดี", phone: "08x-xxx-7730", visits: 26, spent: 7350, points: 735, last: "วันนี้ 10:21", level: "เมล็ดทอง", initials: "พ", avatar: "avatar-3" },
    { name: "กิตติพงษ์ มณี", phone: "06x-xxx-1922", visits: 5, spent: 1120, points: 112, last: "วันนี้ 10:08", level: "เมล็ดเขียว", initials: "ก", avatar: "avatar-4" },
    { name: "อรทัย จันทร์งาม", phone: "08x-xxx-8162", visits: 9, spent: 2055, points: 205, last: "วันนี้ 09:54", level: "เมล็ดเขียว", initials: "อ", avatar: "" },
    { name: "วินัย ธรรมรักษ์", phone: "09x-xxx-6008", visits: 3, spent: 540, points: 54, last: "เมื่อวาน", level: "สมาชิกใหม่", initials: "ว", avatar: "avatar-2" }
  ];

  const team = [
    { name: "พิมพ์ชนก ใจดี", role: "เจ้าของร้าน", shift: "เปิดร้าน · 07:00–15:00", status: "กำลังทำงาน", initials: "พ", avatar: "" },
    { name: "ณัฐวุฒิ ใจเย็น", role: "หัวหน้าบาริสต้า", shift: "เปิดร้าน · 07:00–15:00", status: "กำลังทำงาน", initials: "ณ", avatar: "avatar-2" },
    { name: "ศิริพร ดวงดี", role: "บาริสต้า", shift: "กลางวัน · 10:00–18:00", status: "กำลังทำงาน", initials: "ศ", avatar: "avatar-3" },
    { name: "ปกรณ์ รุ่งเรือง", role: "ครัวและเบเกอรี", shift: "เปิดร้าน · 06:30–14:30", status: "พัก", initials: "ป", avatar: "avatar-4" }
  ];

  const posItems = [
    { name: "ลาเต้เย็น", price: 120, category: "กาแฟ", emoji: "🥛" },
    { name: "อเมริกาโน่", price: 90, category: "กาแฟ", emoji: "☕" },
    { name: "Dirty", price: 145, category: "กาแฟ", emoji: "🧋" },
    { name: "ฟิลเตอร์ประจำวัน", price: 145, category: "กาแฟ", emoji: "🫖" },
    { name: "มัทฉะลาเต้", price: 135, category: "ชา", emoji: "🍵" },
    { name: "ชาพีชโซดา", price: 110, category: "ชา", emoji: "🍑" },
    { name: "ครัวซองต์เนยสด", price: 95, category: "เบเกอรี", emoji: "🥐" },
    { name: "บราวนี่ดาร์กช็อก", price: 85, category: "เบเกอรี", emoji: "🍫" },
    { name: "House Blend 250g", price: 420, category: "เมล็ดกาแฟ", emoji: "🫘" }
  ];

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (char) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char];
    });
  }

  function money(amount) {
    return "฿" + Number(amount || 0).toLocaleString("th-TH");
  }

  function number(amount) {
    return Number(amount || 0).toLocaleString("th-TH");
  }

  function dateLabel() {
    return new Intl.DateTimeFormat("th-TH", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date());
  }

  function showToast(message, type) {
    const toast = document.createElement("div");
    toast.className = "toast" + (type === "error" ? " toast-error" : "");
    toast.textContent = message;
    toastRegion.append(toast);
    window.setTimeout(function () { toast.remove(); }, 3300);
  }

  function updateNavigation() {
    nav.querySelectorAll("[data-page]").forEach(function (button) {
      button.classList.toggle("is-active", button.dataset.page === state.page);
    });
    breadcrumb.textContent = pageNames[state.page] || "ภาพรวม";
    document.title = "บ้านเมล็ด สตูดิโอ — " + (pageNames[state.page] || "ภาพรวม");
    const pending = orders.filter(function (order) { return order.status === "กำลังทำ" || order.status === "รอรับ"; }).length;
    document.getElementById("pending-badge").textContent = String(pending);
  }

  function render() {
    updateNavigation();
    const renderers = {
      overview: renderOverview,
      pos: renderPos,
      orders: renderOrders,
      products: renderProducts,
      inventory: renderInventory,
      customers: renderCustomers,
      team: renderTeam,
      reports: renderReports,
      settings: renderSettings
    };
    root.innerHTML = '<div class="page-enter">' + renderers[state.page]() + "</div>";
    applyGlobalSearch();
  }

  function pageHeading(eyebrow, title, description, actions) {
    return '<div class="page-heading"><div><div class="eyebrow">' + eyebrow + '</div><h1>' + title + '</h1><p>' + description + '</p></div>' +
      (actions ? '<div class="heading-actions">' + actions + "</div>" : "") + "</div>";
  }

  function button(label, action, style, extra) {
    return '<button class="button ' + (style || "") + '" type="button" data-action="' + action + '" ' + (extra || "") + ">" + label + "</button>";
  }

  function orderStatusClass(status) {
    if (status === "เสร็จแล้ว" || status === "รอรับ") return status === "รอรับ" ? "status-pending" : "status-paid";
    if (status === "ยกเลิก") return "status-cancelled";
    return "status-preparing";
  }

  function orderRows(list, limit) {
    return list.slice(0, limit || list.length).map(function (order) {
      return '<tr data-search="' + escapeHtml([order.id, order.customer, order.items, order.channel].join(" ")) + '">' +
        '<td><span class="table-primary">#' + escapeHtml(order.id) + '</span><span class="table-secondary">' + escapeHtml(order.time) + " น.</span></td>" +
        '<td><span class="table-primary">' + escapeHtml(order.customer) + '</span><span class="table-secondary">' + escapeHtml(order.items) + "</span></td>" +
        '<td>' + escapeHtml(order.channel) + '</td><td class="money">' + money(order.total) + '</td>' +
        '<td><span class="status-pill ' + orderStatusClass(order.status) + '">' + escapeHtml(order.status) + '</span></td>' +
        '<td><button class="table-action" type="button" data-action="order-detail" data-id="' + escapeHtml(order.id) + '">รายละเอียด</button></td></tr>';
    }).join("");
  }

  function chartSvg(range) {
    const weekly = range === "สัปดาห์";
    const labels = weekly ? ["จ.", "อ.", "พ.", "พฤ.", "ศ.", "ส.", "อา."] : ["09:00", "11:00", "13:00", "15:00", "17:00", "19:00", "21:00"];
    const values = weekly ? [32, 46, 39, 61, 52, 83, 72] : [21, 48, 34, 69, 54, 91, 67];
    const x = [36, 124, 212, 300, 388, 476, 564];
    const points = values.map(function (value, index) { return [x[index], 145 - value * 1.15]; });
    const path = points.map(function (point, index) { return (index ? "L " : "M ") + point[0] + " " + point[1]; }).join(" ");
    const area = path + " L 564 155 L 36 155 Z";
    const grid = [30, 70, 110, 150].map(function (y) { return '<line class="chart-gridline" x1="26" x2="575" y1="' + y + '" y2="' + y + '"></line>'; }).join("");
    const markers = points.map(function (point, index) { return '<circle class="chart-point" cx="' + point[0] + '" cy="' + point[1] + '" r="3.7"><title>' + labels[index] + " " + money(2450 + values[index] * 67) + "</title></circle>"; }).join("");
    const tickLabels = labels.map(function (label, index) { return '<text class="chart-label" x="' + x[index] + '" y="174" text-anchor="middle">' + label + "</text>"; }).join("");
    return '<svg viewBox="0 0 600 185" role="img" aria-label="กราฟยอดขาย' + (weekly ? "รายวัน" : "รายชั่วโมง") + '">' +
      '<defs><linearGradient id="chart-fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#6ca27a" stop-opacity=".2"></stop><stop offset="100%" stop-color="#6ca27a" stop-opacity="0"></stop></linearGradient></defs>' +
      grid + '<path class="chart-area" d="' + area + '"></path><path class="chart-line" d="' + path + '"></path>' + markers + tickLabels + "</svg>";
  }

  function renderOverview() {
    const recent = orders.slice(0, 5);
    const lowStocks = inventory.filter(function (item) { return item.status === "ใกล้หมด" || item.status === "หมด"; });
    const topItems = [
      { name: "ลาเต้เย็น", meta: "กาแฟนม · 38 แก้ว", amount: 4560, emoji: "🥛" },
      { name: "อเมริกาโน่", meta: "กาแฟดำ · 31 แก้ว", amount: 2790, emoji: "☕" },
      { name: "ครัวซองต์เนยสด", meta: "เบเกอรี · 22 ชิ้น", amount: 2090, emoji: "🥐" },
      { name: "Dirty", meta: "กาแฟนม · 17 แก้ว", amount: 2465, emoji: "🧋" }
    ];
    return '<section class="brand-home" aria-labelledby="brand-home-title"><div class="brand-home-copy"><div class="brand-home-kicker"><span class="brand-home-seal" aria-hidden="true">บ.</span><span>BAAN MLET <i>·</i> COFFEE STUDIO</span></div><h1 id="brand-home-title">บ้านเมล็ด</h1><p class="brand-home-tagline">กาแฟดี ๆ และช่วงเวลาดี ๆ<br>ในแบบของบ้านเรา</p><p class="brand-home-subtitle">คัดเมล็ดจากดอยไทย ชงด้วยใจที่เชียงใหม่ — ยินดีต้อนรับกลับบ้านนะ คุณพิมพ์ชนก</p><div class="brand-home-actions"><button class="brand-home-primary" type="button" data-page="pos">เปิดหน้าขาย <span aria-hidden="true">↗</span></button><button class="brand-home-secondary" type="button" data-page="orders">ดูออเดอร์วันนี้ <span aria-hidden="true">→</span></button></div><div class="brand-home-meta"><span><i></i> เปิดให้บริการ · 07:00–21:00</span><b></b><span>' + dateLabel() + "</span></div></div><div class=\"brand-home-visual\"><img src=\"https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&amp;fit=crop&amp;w=1400&amp;q=88\" alt=\"บาริสต้ากำลังชงกาแฟในบรรยากาศอบอุ่นของร้าน\" fetchpriority=\"high\"><div class=\"brand-home-image-shade\"></div><span class=\"brand-home-photo-note\">SLOW MORNINGS, GOOD COFFEE</span><div class=\"brand-home-feature\"><span class=\"brand-home-feature-mark\" aria-hidden=\"true\">✳</span><span><small>เมล็ดประจำวันนี้</small><strong>ดอยสะเก็ด · Natural</strong></span><span class=\"brand-home-feature-arrow\" aria-hidden=\"true\">↗</span></div><span class=\"brand-home-image-index\">18°47' N&nbsp; / &nbsp;98°59' E</span></div><span class=\"brand-home-orbit\" aria-hidden=\"true\"></span></section>" +
      '<section class="overview-grid" aria-label="สรุปผลประกอบการวันนี้">' +
      metricCard("ยอดขายวันนี้", "฿12,840", "↑ 12.8%", "เทียบกับวันก่อน", "↗") +
      metricCard("ออเดอร์ทั้งหมด", "86", "↑ 8 รายการ", "เทียบกับวันก่อน", "▤") +
      metricCard("ยอดเฉลี่ย / บิล", "฿149", "↑ 4.2%", "เทียบกับสัปดาห์ก่อน", "◌") +
      metricCard("สมาชิกใหม่", "12", "↑ 3 คน", "สมัครวันนี้", "♧") +
      '</section><section class="overview-middle" aria-label="รายงานยอดขาย">' +
      '<article class="panel chart-panel"><div class="panel-heading chart-heading"><div><h2>จังหวะของร้าน</h2><p>ยอดขายรวม · วันนี้</p><div class="chart-total">฿12,840 <small>↑ 12.8% จากเมื่อวาน</small></div></div>' +
      '<div class="chart-switch" role="group" aria-label="ช่วงเวลาของกราฟ"><button type="button" class="' + (state.chartRange === "สัปดาห์" ? "is-selected" : "") + '" data-action="chart-range" data-range="สัปดาห์">สัปดาห์</button><button type="button" class="' + (state.chartRange === "วันนี้" ? "is-selected" : "") + '" data-action="chart-range" data-range="วันนี้">วันนี้</button></div></div><div class="chart-wrap">' + chartSvg(state.chartRange) + "</div></article>" +
      '<article class="panel sales-panel"><div class="panel-heading"><div><h2>เมนูขายดี</h2><p>5 อันดับประจำวันนี้</p></div><button class="panel-link" type="button" data-page="products">ดูเมนู <span aria-hidden="true">→</span></button></div><div class="sales-list">' +
      topItems.map(function (item) { return '<div class="sales-row"><span class="sales-thumb">' + item.emoji + '</span><span class="sales-copy"><strong>' + item.name + '</strong><small>' + item.meta + '</small></span><span class="sales-amount"><strong>' + money(item.amount) + '</strong><small>ยอดขาย</small></span></div>'; }).join("") +
      "</div></article></section>" +
      '<section class="overview-bottom"><article class="panel orders-panel"><div class="panel-heading"><div><h2>ออเดอร์ล่าสุด</h2><p>รายการที่เกิดขึ้นในร้าน</p></div><button class="panel-link" type="button" data-page="orders">ดูทั้งหมด <span aria-hidden="true">→</span></button></div><div class="table-wrap"><table class="order-table"><thead><tr><th>คำสั่งซื้อ</th><th>ลูกค้า / รายการ</th><th>ช่องทาง</th><th>ยอดรวม</th><th>สถานะ</th><th></th></tr></thead><tbody>' + orderRows(recent, 5) + "</tbody></table></div></article>" +
      '<article class="panel stock-panel"><div class="panel-heading"><div><h2>สต็อกที่ควรดู</h2><p>' + lowStocks.length + " รายการต้องเติมเร็ว ๆ นี้</p></div><button class=\"panel-link\" type=\"button\" data-page=\"inventory\">จัดการ <span aria-hidden=\"true\">→</span></button></div><div class=\"stock-list\">" +
      lowStocks.slice(0, 4).map(function (item) {
        const percentage = Math.min(100, Math.round(item.stock / item.par * 100));
        return '<div class="stock-row"><span class="stock-info"><strong>' + escapeHtml(item.name) + '</strong><small>' + escapeHtml(item.location) + '</small></span><span class="stock-bar"><i class="' + (percentage < 40 ? "critical" : "") + '" style="width:' + percentage + '%"></i></span><span class="stock-qty"><b>' + item.stock + "</b> " + item.unit + "</span></div>";
      }).join("") + (lowStocks.length ? "" : '<div class="stock-empty">สต็อกทุกอย่างพร้อมขายแล้ว เยี่ยมเลย!</div>') +
      "</div></article></section>";
  }

  function metricCard(label, value, trend, note, icon) {
    return '<article class="metric-card"><div class="metric-top"><span>' + label + '</span><span class="metric-icon" aria-hidden="true">' + icon + '</span></div><div class="metric-value"><strong>' + value + '</strong></div><div class="metric-bottom"><span class="trend-up">' + trend + "</span><span>" + note + "</span></div></article>";
  }

  function renderOrders() {
    const filters = ["ทั้งหมด", "กำลังทำ", "รอรับ", "เสร็จแล้ว", "ยกเลิก"];
    let filtered = orders.filter(function (order) {
      return (state.orderFilter === "ทั้งหมด" || order.status === state.orderFilter) &&
        (state.orderChannel === "ทุกช่องทาง" || order.channel === state.orderChannel);
    });
    if (state.globalQuery) filtered = filtered.filter(function (order) { return [order.id, order.customer, order.items, order.channel].join(" ").toLowerCase().includes(state.globalQuery.toLowerCase()); });
    return pageHeading("งานหน้าร้าน", "คำสั่งซื้อ", "ติดตามทุกออเดอร์จากหน้าร้านและเดลิเวอรี พร้อมอัปเดตสถานะได้ทันที.", button('<span class="button-icon">＋</span> สร้างออเดอร์', "go-pos", "button-primary")) +
      '<div class="summary-strip"><div class="summary-cell"><small>ออเดอร์วันนี้</small><strong>86 <span>รายการ</span></strong></div><div class="summary-cell"><small>กำลังดำเนินการ</small><strong>' + orders.filter(function (order) { return order.status === "กำลังทำ" || order.status === "รอรับ"; }).length + ' <span>รายการ</span></strong></div><div class="summary-cell"><small>ยอดขายวันนี้</small><strong>฿12,840</strong></div></div>' +
      '<div class="toolbar-row"><div class="tab-list" role="tablist" aria-label="กรองคำสั่งซื้อ">' + filters.map(function (filter) { return '<button type="button" class="tab-button ' + (state.orderFilter === filter ? "is-active" : "") + '" data-action="order-filter" data-filter="' + filter + '" role="tab" aria-selected="' + (state.orderFilter === filter) + '">' + filter + "</button>"; }).join("") + '</div><div class="toolbar-group"><select class="select-control" id="order-channel" aria-label="เลือกช่องทาง"><option ' + (state.orderChannel === "ทุกช่องทาง" ? "selected" : "") + '>ทุกช่องทาง</option><option ' + (state.orderChannel === "หน้าร้าน" ? "selected" : "") + '>หน้าร้าน</option><option ' + (state.orderChannel === "เดลิเวอรี" ? "selected" : "") + '>เดลิเวอรี</option></select><button class="button" type="button" data-action="export">↓ ส่งออกรายการ</button></div></div>' +
      '<section class="panel module-panel"><div class="table-wrap"><table><thead><tr><th>คำสั่งซื้อ</th><th>ลูกค้า / รายการ</th><th>ช่องทาง</th><th>ยอดรวม</th><th>สถานะ</th><th>จัดการ</th></tr></thead><tbody>' + (filtered.length ? orderRows(filtered) : '<tr><td colspan="6"><div class="empty-state"><strong>ไม่พบคำสั่งซื้อ</strong>ลองเปลี่ยนตัวกรองหรือคำค้นหา</div></td></tr>') + "</tbody></table></div></section>";
  }

  function renderProducts() {
    const categories = ["ทั้งหมด", "กาแฟ", "ชา", "เบเกอรี", "เมล็ดกาแฟ"];
    let filtered = products.filter(function (product) { return state.productFilter === "ทั้งหมด" || product.category === state.productFilter; });
    if (state.globalQuery) filtered = filtered.filter(function (product) { return [product.name, product.category, product.description].join(" ").toLowerCase().includes(state.globalQuery.toLowerCase()); });
    return pageHeading("สิ่งที่ลูกค้าหลงรัก", "สินค้าและเมนู", "จัดการราคา เมนู และสถานะการขายของสาขานิมมาน", button('<span class="button-icon">＋</span> เพิ่มสินค้า', "add-product", "button-primary")) +
      '<div class="toolbar-row"><div class="tab-list" role="tablist" aria-label="กรองหมวดหมู่สินค้า">' + categories.map(function (category) { return '<button type="button" class="tab-button ' + (state.productFilter === category ? "is-active" : "") + '" data-action="product-filter" data-filter="' + category + '" role="tab" aria-selected="' + (state.productFilter === category) + '">' + category + "</button>"; }).join("") + '</div><div class="toolbar-group"><button class="button" type="button" data-action="export">↓ ส่งออกรายการ</button></div></div>' +
      '<div class="product-grid">' + (filtered.length ? filtered.map(function (product) {
        return '<article class="product-card" data-search="' + escapeHtml([product.name, product.category, product.description].join(" ")) + '"><div class="product-art ' + product.art + '"><span aria-hidden="true">' + product.emoji + '</span></div><div class="product-card-body"><div class="product-card-top"><div><h3>' + escapeHtml(product.name) + '</h3><span class="table-secondary">' + escapeHtml(product.category) + '</span></div><span class="status-pill ' + (product.status === "พร้อมขาย" ? "status-active" : "status-low") + '">' + escapeHtml(product.status) + '</span></div><p>' + escapeHtml(product.description) + '</p><div class="product-card-foot"><strong>' + money(product.price) + '</strong><small>ต้นทุน ' + money(product.cost) + '</small><button class="mini-icon-button" type="button" aria-label="แก้ไข ' + escapeHtml(product.name) + '" data-action="edit-product" data-id="' + escapeHtml(product.id) + '">✎</button></div></div></article>';
      }).join("") : '<div class="empty-state"><strong>ยังไม่มีสินค้าในหมวดนี้</strong>เพิ่มเมนูใหม่หรือเลือกหมวดอื่น</div>') + "</div>";
  }

  function renderInventory() {
    const filters = ["ทั้งหมด", "เมล็ดกาแฟ", "นมและทางเลือก", "เบเกอรี", "บรรจุภัณฑ์", "วัตถุดิบอื่น"];
    let filtered = inventory.filter(function (item) { return state.inventoryFilter === "ทั้งหมด" || item.type === state.inventoryFilter; });
    if (state.globalQuery) filtered = filtered.filter(function (item) { return [item.name, item.type, item.location].join(" ").toLowerCase().includes(state.globalQuery.toLowerCase()); });
    const low = inventory.filter(function (item) { return item.status === "ใกล้หมด" || item.status === "หมด"; });
    return pageHeading("หลังบาร์ต้องพร้อม", "สต็อกวัตถุดิบ", "รู้ก่อนหมด เติมของได้ทัน ลดของเสียและไม่พลาดเมนูโปรด", button('<span class="button-icon">＋</span> รับสินค้าเข้า', "stock-in", "button-primary")) +
      '<div class="summary-strip"><div class="summary-cell"><small>วัตถุดิบทั้งหมด</small><strong>' + inventory.length + ' <span>รายการ</span></strong></div><div class="summary-cell"><small>ต้องสั่งเพิ่ม</small><strong>' + low.length + ' <span>รายการ</span></strong></div><div class="summary-cell"><small>รายการหมด</small><strong>' + inventory.filter(function (item) { return item.status === "หมด"; }).length + ' <span>รายการ</span></strong></div></div>' +
      (low.length ? '<div class="low-banner"><span class="low-banner-mark">!</span><span class="low-banner-copy"><strong>มี ' + low.length + ' รายการต่ำกว่าระดับที่ตั้งไว้</strong><small>' + low.map(function (item) { return escapeHtml(item.name); }).join(" · ") + '</small></span><button class="button button-warm" type="button" data-action="stock-in">เติมสต็อก</button></div>' : "") +
      '<div class="toolbar-row"><div class="tab-list" role="tablist" aria-label="กรองหมวดหมู่วัตถุดิบ">' + filters.map(function (filter) { return '<button type="button" class="tab-button ' + (state.inventoryFilter === filter ? "is-active" : "") + '" data-action="inventory-filter" data-filter="' + filter + '" role="tab" aria-selected="' + (state.inventoryFilter === filter) + '">' + filter + "</button>"; }).join("") + '</div><div class="toolbar-group"><button class="button" type="button" data-action="export">↓ ส่งออกรายการ</button></div></div>' +
      '<section class="panel module-panel"><div class="table-wrap"><table><thead><tr><th>วัตถุดิบ</th><th>ตำแหน่ง</th><th>คงเหลือ / ขั้นต่ำ</th><th>สถานะ</th><th>ปรับจำนวน</th><th></th></tr></thead><tbody>' + (filtered.length ? filtered.map(function (item) {
        const pct = Math.min(100, Math.round(item.stock / item.par * 100));
        const levelClass = item.status === "หมด" ? "danger" : item.status === "ใกล้หมด" ? "warn" : "";
        const statusClass = item.status === "ปกติ" ? "status-active" : item.status === "หมด" ? "status-out" : "status-low";
        return '<tr data-search="' + escapeHtml([item.name, item.type, item.location].join(" ")) + '"><td><div class="table-title"><span class="table-thumb">' + item.emoji + '</span><span>' + escapeHtml(item.name) + '<span class="table-secondary">' + escapeHtml(item.type) + "</span></span></div></td><td>" + escapeHtml(item.location) + '</td><td class="stock-cell"><strong>' + item.stock + " " + item.unit + '</strong><small>ขั้นต่ำ ' + item.par + " " + item.unit + '</small><span class="stock-level"><i class="' + levelClass + '" style="width:' + pct + '%"></i></span></td><td><span class="status-pill ' + statusClass + '">' + escapeHtml(item.status) + '</span></td><td><span class="quantity-control"><button type="button" aria-label="ลด ' + escapeHtml(item.name) + '" data-action="stock-adjust" data-id="' + item.id + '" data-delta="-1">−</button><span>' + item.stock + '</span><button type="button" aria-label="เพิ่ม ' + escapeHtml(item.name) + '" data-action="stock-adjust" data-id="' + item.id + '" data-delta="1">+</button></span></td><td><button class="table-action" type="button" data-action="stock-in-one" data-id="' + item.id + '">รับเข้า</button></td></tr>';
      }).join("") : '<tr><td colspan="6"><div class="empty-state"><strong>ไม่พบวัตถุดิบ</strong>ลองเปลี่ยนตัวกรองหรือคำค้นหา</div></td></tr>') + "</tbody></table></div></section>";
  }

  function renderCustomers() {
    let list = customers.filter(function (customer) { return state.customerLevel === "ทุกระดับสมาชิก" || customer.level === state.customerLevel; });
    if (state.globalQuery) list = list.filter(function (customer) { return [customer.name, customer.phone, customer.level].join(" ").toLowerCase().includes(state.globalQuery.toLowerCase()); });
    return pageHeading("สร้างความสัมพันธ์ดี ๆ", "ลูกค้าของเรา", "ดูแลสมาชิก เข้าใจคนที่แวะมาหา และมอบสิ่งดี ๆ กลับไป", button('<span class="button-icon">＋</span> เพิ่มสมาชิก', "add-customer", "button-primary")) +
      '<div class="summary-strip"><div class="summary-cell"><small>สมาชิกทั้งหมด</small><strong>1,284 <span>คน</span></strong></div><div class="summary-cell"><small>สมาชิกใหม่เดือนนี้</small><strong>86 <span>คน</span></strong></div><div class="summary-cell"><small>คะแนนที่ใช้ได้</small><strong>28,460 <span>แต้ม</span></strong></div></div>' +
      '<div class="toolbar-row"><div class="toolbar-group"><label class="search-field"><input class="input-control" type="search" data-local-search placeholder="ค้นหาชื่อหรือเบอร์โทร" aria-label="ค้นหาลูกค้า" /></label></div><div class="toolbar-group"><select class="select-control" id="customer-level" aria-label="กรองระดับสมาชิก"><option ' + (state.customerLevel === "ทุกระดับสมาชิก" ? "selected" : "") + '>ทุกระดับสมาชิก</option><option ' + (state.customerLevel === "เมล็ดทอง" ? "selected" : "") + '>เมล็ดทอง</option><option ' + (state.customerLevel === "เมล็ดเขียว" ? "selected" : "") + '>เมล็ดเขียว</option><option ' + (state.customerLevel === "สมาชิกใหม่" ? "selected" : "") + '>สมาชิกใหม่</option></select><button class="button" type="button" data-action="export">↓ ส่งออกรายการ</button></div></div>' +
      '<section class="panel module-panel"><div class="table-wrap"><table><thead><tr><th>สมาชิก</th><th>เบอร์โทร</th><th>มาใช้บริการ</th><th>ยอดซื้อสะสม</th><th>คะแนน</th><th>ล่าสุด</th><th>ระดับ</th></tr></thead><tbody>' + (list.length ? list.map(function (customer, index) {
        return '<tr data-search="' + escapeHtml([customer.name, customer.phone, customer.level].join(" ")) + '"><td><div class="table-title"><span class="customer-avatar ' + customer.avatar + '">' + customer.initials + '</span><span class="table-primary">' + escapeHtml(customer.name) + '</span></div></td><td>' + escapeHtml(customer.phone) + '</td><td>' + customer.visits + " ครั้ง</td><td class=\"money\">" + money(customer.spent) + '</td><td>' + number(customer.points) + ' แต้ม</td><td>' + escapeHtml(customer.last) + '</td><td><span class="status-pill ' + (customer.level === "เมล็ดทอง" ? "status-pending" : "status-active") + '">' + escapeHtml(customer.level) + '</span></td></tr>';
      }).join("") : '<tr><td colspan="7"><div class="empty-state"><strong>ยังไม่พบสมาชิก</strong>ลองค้นหาด้วยชื่ออื่น</div></td></tr>') + "</tbody></table></div></section>";
  }

  function renderTeam() {
    return pageHeading("คนสำคัญหลังเคาน์เตอร์", "ทีมงาน", "จัดกะ ดูสถานะทีม และช่วยให้ทุกช่วงเวลาในร้านไหลลื่น", button('<span class="button-icon">＋</span> เพิ่มพนักงาน', "add-team", "button-primary")) +
      '<div class="summary-strip"><div class="summary-cell"><small>ทีมทั้งหมด</small><strong>' + team.length + ' <span>คน</span></strong></div><div class="summary-cell"><small>กำลังเข้างาน</small><strong>' + team.filter(function (person) { return person.status === "กำลังทำงาน"; }).length + ' <span>คน</span></strong></div><div class="summary-cell"><small>กะถัดไป</small><strong>14:30 <span>น.</span></strong></div></div>' +
      '<div class="toolbar-row"><div><strong class="tiny-label">ตารางกะวันนี้ · ' + dateLabel() + '</strong></div><div class="toolbar-group"><button class="button" type="button" data-action="export">ดูตารางทั้งสัปดาห์</button></div></div>' +
      '<section class="panel module-panel"><div class="table-wrap"><table><thead><tr><th>สมาชิกทีม</th><th>ตำแหน่ง</th><th>กะวันนี้</th><th>สถานะ</th><th>เวลาเข้างาน</th><th>จัดการ</th></tr></thead><tbody>' + team.map(function (person, index) {
        return '<tr data-search="' + escapeHtml([person.name, person.role].join(" ")) + '"><td><div class="team-person"><span class="customer-avatar ' + person.avatar + '">' + person.initials + '</span><span class="table-primary">' + escapeHtml(person.name) + '</span></div></td><td>' + escapeHtml(person.role) + '</td><td>' + escapeHtml(person.shift) + '</td><td><span class="status-pill ' + (person.status === "พัก" ? "status-pending" : "status-active") + '">' + escapeHtml(person.status) + '</span></td><td>' + (index === 0 ? "06:56 น." : index === 1 ? "07:03 น." : index === 2 ? "09:54 น." : "06:29 น.") + '</td><td><button class="table-action" data-action="edit-team" data-id="' + index + '" type="button">แก้ไข</button></td></tr>';
      }).join("") + "</tbody></table></div></section>" +
      '<h2 class="section-label">กะวันนี้</h2><div class="panel shift-summary"><div class="shift-summary-column"><span class="tiny-label">เปิดร้าน</span><div class="shift-dots"><i></i><i></i><i></i></div><span class="table-secondary">06:30–14:30 · 3 คน</span></div><div class="shift-summary-column"><span class="tiny-label">กลางวัน</span><div class="shift-dots"><i></i><i class="off"></i><i class="off"></i></div><span class="table-secondary">10:00–18:00 · 1 คน</span></div><div class="shift-summary-column"><span class="tiny-label">ปิดร้าน</span><div class="shift-dots"><i class="off"></i><i class="off"></i><i class="off"></i></div><span class="table-secondary">14:30–22:00 · 0 คน</span></div></div>';
  }

  function renderReports() {
    return pageHeading("ตัวเลขที่เล่าเรื่องร้าน", "รายงาน", "เห็นภาพรวมรายรับ เมนูที่ใช่ และจังหวะที่ร้านคึกคัก", '<select class="select-control" id="report-range" aria-label="ช่วงเวลารายงาน"><option ' + (state.reportRange === "7 วัน" ? "selected" : "") + '>7 วัน</option><option ' + (state.reportRange === "30 วัน" ? "selected" : "") + '>30 วัน</option><option ' + (state.reportRange === "ปีนี้" ? "selected" : "") + '>ปีนี้</option></select><button class="button" type="button" data-action="export">↓ ดาวน์โหลดรายงาน</button>') +
      '<section class="report-highlight"><div><div class="eyebrow">ยอดขายสุทธิ · ' + state.reportRange + ' ล่าสุด</div><h2>฿86,420</h2><p>ยอดขายเติบโตขึ้น 12.8% จากช่วงเวลาก่อนหน้า</p></div><div class="report-stat-list"><div class="report-stat"><small>จำนวนบิล</small><strong>582</strong></div><div class="report-stat"><small>เฉลี่ยต่อบิล</small><strong>฿148</strong></div><div class="report-stat"><small>ลูกค้าซ้ำ</small><strong>68%</strong></div></div></section>' +
      '<div class="overview-middle"><article class="panel chart-panel"><div class="panel-heading"><div><h2>ยอดขายตามช่วงเวลา</h2><p>เปรียบเทียบรายได้และจำนวนออเดอร์</p></div><span class="status-pill status-active">↑ 12.8%</span></div><div class="chart-wrap">' + chartSvg("สัปดาห์") + "</div></article>" +
      '<article class="panel sales-panel"><div class="panel-heading"><div><h2>ยอดขายแยกหมวด</h2><p>สัดส่วนรายได้ตามประเภท</p></div></div><div class="sales-list">' +
      [{ name: "กาแฟ", amount: 48900, pct: 57, emoji: "☕" }, { name: "ชาและเครื่องดื่ม", amount: 17200, pct: 20, emoji: "🍵" }, { name: "เบเกอรี", amount: 12800, pct: 15, emoji: "🥐" }, { name: "เมล็ดและสินค้า", amount: 7520, pct: 8, emoji: "🫘" }].map(function (item) {
        return '<div class="sales-row"><span class="sales-thumb">' + item.emoji + '</span><span class="sales-copy"><strong>' + item.name + '</strong><small>' + item.pct + '% ของยอดขาย</small></span><span class="sales-amount"><strong>' + money(item.amount) + "</strong><small>สุทธิ</small></span></div>";
      }).join("") + '</div></article></div>' +
      '<h2 class="section-label">เมนูที่ลูกค้ากลับมาสั่ง</h2><section class="panel module-panel"><div class="table-wrap"><table><thead><tr><th>อันดับ</th><th>เมนู</th><th>จำนวนที่ขาย</th><th>ยอดขาย</th><th>สัดส่วน</th></tr></thead><tbody>' +
      [{ name: "ลาเต้เย็น", count: 184, total: 22080, pct: "25.5%" }, { name: "อเมริกาโน่", count: 139, total: 12510, pct: "14.5%" }, { name: "ครัวซองต์เนยสด", count: 98, total: 9310, pct: "10.8%" }, { name: "Dirty", count: 74, total: 10730, pct: "12.4%" }].map(function (item, index) {
        return '<tr><td><span class="status-pill ' + (index === 0 ? "status-pending" : "status-active") + '">#' + (index + 1) + '</span></td><td class="table-primary">' + item.name + '</td><td>' + item.count + '</td><td class="money">' + money(item.total) + '</td><td>' + item.pct + "</td></tr>";
      }).join("") + "</tbody></table></div></section>";
  }

  function renderSettings() {
    const tabs = ["ข้อมูลร้าน", "การแจ้งเตือน", "หน้าร้าน", "สมาชิกและสิทธิ์"];
    let content = "";
    if (state.settingsTab === "ข้อมูลร้าน") {
      content = '<h2>ข้อมูลสาขา</h2><p>จัดการข้อมูลที่แสดงในใบเสร็จและหน้าร้าน</p><div class="form-grid"><div class="form-field"><label for="settings-store-name">ชื่อร้าน</label><input id="settings-store-name" value="บ้านเมล็ด คอฟฟี่สตูดิโอ" /></div><div class="form-field"><label for="settings-branch-name">ชื่อสาขา</label><input id="settings-branch-name" value="นิมมาน · เชียงใหม่" /></div><div class="form-field"><label for="settings-phone">เบอร์โทรศัพท์</label><input id="settings-phone" type="tel" value="053-xxx-xxx" /></div><div class="form-field"><label for="settings-email">อีเมล</label><input id="settings-email" type="email" value="hello@baanmlet.example" /></div><div class="form-field full"><label for="settings-address">ที่อยู่</label><textarea id="settings-address">ถนนนิมมานเหมินท์ อำเภอเมือง จังหวัดเชียงใหม่</textarea></div></div><div class="modal-actions"><button class="button button-primary" type="button" data-action="save-settings">บันทึกการเปลี่ยนแปลง</button></div>';
    } else if (state.settingsTab === "การแจ้งเตือน") {
      content = '<h2>การแจ้งเตือน</h2><p>เลือกสิ่งที่อยากให้ระบบช่วยเตือนระหว่างวัน</p>' + settingRow("เตือนเมื่อวัตถุดิบใกล้หมด", "รับการแจ้งเตือนเมื่อสินค้าเหลือต่ำกว่าระดับขั้นต่ำ", "lowStock") + settingRow("สรุปยอดขายประจำวัน", "รับสรุปยอดขายหลังปิดร้าน", "dailySummary") + settingRow("เสียงแจ้งเตือนออเดอร์", "เปิดเสียงเมื่อมีออเดอร์ใหม่เข้ามา", "sound");
    } else if (state.settingsTab === "หน้าร้าน") {
      content = '<h2>การทำงานหน้าร้าน</h2><p>ค่าเริ่มต้นที่ช่วยให้ทีมทำงานได้รวดเร็ว</p>' + settingRow("แสดงเมนูหมดชั่วคราว", "ยังแสดงเมนูแต่ระบุว่าหมด เพื่อไม่ให้ลูกค้าสับสน", "outOfStock") + settingRow("ถามยืนยันก่อนยกเลิกบิล", "ลดโอกาสยกเลิกรายการผิดพลาด", "confirmCancel") + '<div class="setting-row"><span><strong>ภาษาบนใบเสร็จ</strong><small>เลือกภาษาหลักที่แสดงให้ลูกค้า</small></span><select class="select-control" aria-label="ภาษาบนใบเสร็จ"><option>ภาษาไทย</option><option>ไทย / English</option></select></div>';
    } else {
      content = '<h2>สมาชิกและสิทธิ์</h2><p>ตรวจสอบบทบาทของผู้ใช้งานในสาขานี้</p>' + team.map(function (person) { return '<div class="setting-row"><span><strong>' + escapeHtml(person.name) + '</strong><small>' + escapeHtml(person.role) + '</small></span><button class="button" type="button" data-action="edit-team">จัดการสิทธิ์</button></div>'; }).join("");
    }
    return pageHeading("ปรับร้านให้เป็นจังหวะของคุณ", "ตั้งค่าร้าน", "จัดการข้อมูลร้าน การแจ้งเตือน และวิธีทำงานในแต่ละวัน") +
      '<div class="settings-grid"><nav class="panel settings-tabs" aria-label="หมวดการตั้งค่า">' + tabs.map(function (tab) { return '<button class="settings-tab ' + (state.settingsTab === tab ? "is-active" : "") + '" type="button" data-action="settings-tab" data-tab="' + tab + '">' + tab + "</button>"; }).join("") + '</nav><section class="panel settings-content">' + content + "</section></div>";
  }

  function settingRow(title, description, key) {
    const checked = Boolean(state.settings[key]);
    return '<div class="setting-row"><span><strong>' + title + '</strong><small>' + description + '</small></span><button class="toggle" type="button" role="switch" aria-checked="' + checked + '" aria-label="' + title + '" data-action="toggle-setting" data-key="' + key + '"></button></div>';
  }

  function renderPos() {
    const categories = ["ทั้งหมด", "กาแฟ", "ชา", "เบเกอรี", "เมล็ดกาแฟ"];
    const filtered = posItems.filter(function (item) { return posState.category === "ทั้งหมด" || item.category === posState.category; });
    let subtotal = 0;
    let count = 0;
    cart.forEach(function (item) { subtotal += item.price * item.quantity; count += item.quantity; });
    const tax = Math.round(subtotal * 7 / 107);
    const rows = Array.from(cart.entries()).map(function (entry) {
      const item = entry[1];
      return '<div class="pos-cart-row"><div><strong>' + escapeHtml(item.name) + '</strong><small>' + money(item.price) + " × " + item.quantity + '</small></div><span class="quantity-control"><button type="button" aria-label="ลด ' + escapeHtml(item.name) + '" data-action="pos-quantity" data-id="' + escapeHtml(entry[0]) + '" data-delta="-1">−</button><span>' + item.quantity + '</span><button type="button" aria-label="เพิ่ม ' + escapeHtml(item.name) + '" data-action="pos-quantity" data-id="' + escapeHtml(entry[0]) + '" data-delta="1">+</button></span></div>';
    }).join("");
    return pageHeading("ช่วงเวลาดี ๆ ที่เคาน์เตอร์", "ขายหน้าร้าน", "แตะเมนูเพื่อเพิ่มลงบิล · เช็กยอดก่อนรับชำระ", '<span class="date-chip"><i></i> บิลใหม่ · ' + new Date().toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" }) + "</span>") +
      '<div class="pos-layout"><section class="panel pos-menu-panel"><div class="pos-menu-head"><h2>เลือกเมนู</h2><label class="search-field"><input class="input-control" type="search" data-pos-search placeholder="ค้นหาเมนู" aria-label="ค้นหาเมนู" /></label></div><div class="pos-filters">' + categories.map(function (category) { return '<button type="button" class="pos-filter ' + (posState.category === category ? "is-active" : "") + '" data-action="pos-category" data-category="' + category + '">' + category + "</button>"; }).join("") + '</div><div class="pos-items">' + filtered.map(function (item) { return '<button class="pos-item" type="button" data-action="pos-add" data-name="' + escapeHtml(item.name) + '" data-price="' + item.price + '" data-emoji="' + item.emoji + '" data-search="' + escapeHtml(item.name + " " + item.category) + '"><span class="pos-item-emoji" aria-hidden="true">' + item.emoji + '</span><strong>' + escapeHtml(item.name) + '</strong><small>' + escapeHtml(item.category) + '</small><span class="pos-item-price">' + money(item.price) + "</span></button>"; }).join("") + "</div></section>" +
      '<aside class="panel pos-cart"><div class="pos-cart-head"><h2>รายการในบิล</h2><span>' + count + ' รายการ</span></div>' +
      '<select class="select-control pos-customer-select" id="pos-customer-select" aria-label="เลือกสมาชิก"><option value="ลูกค้าทั่วไป"' + (posState.customer === "ลูกค้าทั่วไป" ? " selected" : "") + '>ลูกค้าทั่วไป</option>' +
      customers.slice(0, 4).map(function (customer) { return '<option value="' + escapeHtml(customer.name) + '"' + (posState.customer === customer.name ? " selected" : "") + ">" + escapeHtml(customer.name) + "</option>"; }).join("") +
      '</select><div class="pos-cart-items">' + (rows || '<div class="pos-empty"><span aria-hidden="true">☕</span>ยังไม่มีเมนูในบิล<br>แตะเมนูทางซ้ายเพื่อเริ่มรายการ</div>') +
      '</div><div class="pos-cart-totals"><div class="pos-total-line"><span>ยอดก่อนภาษี</span><span class="money">' + money(subtotal - tax) + '</span></div>' +
      '<div class="pos-total-line"><span>ภาษีมูลค่าเพิ่ม 7%</span><span class="money">' + money(tax) + '</span></div><div class="pos-total-line grand"><span>ยอดสุทธิ</span><strong class="money">' + money(subtotal) + '</strong></div></div>' +
      '<div class="pay-methods" role="group" aria-label="วิธีชำระเงิน">' + ["เงินสด", "โอน / QR", "บัตร"].map(function (method) { return '<button class="pay-method ' + (posState.payment === method ? "is-active" : "") + '" type="button" data-action="payment-method" data-method="' + method + '">' + method + "</button>"; }).join("") +
      '</div><button class="button button-primary pos-checkout" type="button" data-action="checkout" ' + (count ? "" : "disabled") + '>รับชำระ ' + money(subtotal) + "</button></aside></div>";
  }

  function applyGlobalSearch() {
    applySearchFilters();
  }

  function applyLocalSearch() {
    applySearchFilters();
  }

  function applySearchFilters() {
    const globalQuery = state.globalQuery.trim().toLowerCase();
    const localInput = root.querySelector("[data-local-search]");
    const localQuery = localInput ? localInput.value.trim().toLowerCase() : "";
    root.querySelectorAll("[data-search]").forEach(function (element) {
      const searchText = element.dataset.search.toLowerCase();
      element.hidden = (globalQuery && !searchText.includes(globalQuery)) ||
        (localQuery && !searchText.includes(localQuery));
    });
  }

  function findOrder(id) {
    return orders.find(function (order) { return order.id === id; });
  }

  function showModal(title, subtitle, body) {
    modalLayer.innerHTML = '<section class="modal-card" role="dialog" aria-modal="true" aria-labelledby="modal-title"><header class="modal-head"><div><h2 id="modal-title">' + title + '</h2><p>' + subtitle + '</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="ปิด">×</button></header><div class="modal-body">' + body + "</div></section>";
    modalLayer.hidden = false;
    const first = modalLayer.querySelector("input, select, textarea, button");
    if (first) first.focus();
  }

  function closeModal() {
    modalLayer.hidden = true;
    modalLayer.innerHTML = "";
  }

  function orderDetail(id) {
    const order = findOrder(id);
    if (!order) return;
    const options = ["กำลังทำ", "รอรับ", "เสร็จแล้ว", "ยกเลิก"].map(function (status) { return '<option ' + (order.status === status ? "selected" : "") + ">" + status + "</option>"; }).join("");
    showModal("คำสั่งซื้อ #" + escapeHtml(order.id), "ตรวจสอบรายการก่อนอัปเดตสถานะ", '<div class="detail-grid"><div class="detail-block"><small>ลูกค้า</small><strong>' + escapeHtml(order.customer) + '</strong></div><div class="detail-block"><small>เวลาสั่ง</small><strong>' + escapeHtml(order.time) + " น. · " + escapeHtml(order.channel) + '</strong></div><div class="detail-block"><small>รายการ</small><strong>' + escapeHtml(order.items) + '</strong></div><div class="detail-block"><small>ยอดรวม</small><strong>' + money(order.total) + '</strong></div></div><form id="order-status-form"><div class="form-field" style="margin-top:14px"><label for="order-status">สถานะคำสั่งซื้อ</label><select id="order-status" name="status">' + options + '</select></div><input type="hidden" name="id" value="' + escapeHtml(order.id) + '"><div class="modal-actions"><button class="button" type="button" data-action="close-modal">ปิด</button><button class="button button-primary" type="submit">บันทึกสถานะ</button></div></form>');
  }

  function productForm(product) {
    const editing = Boolean(product);
    showModal(editing ? "แก้ไขสินค้า" : "เพิ่มสินค้าใหม่", "ข้อมูลตัวอย่างจะถูกบันทึกไว้ในหน้าจอนี้เท่านั้น", '<form id="product-form"><div class="form-grid"><div class="form-field full"><label for="product-name">ชื่อสินค้า</label><input id="product-name" name="name" required maxlength="60" value="' + escapeHtml(product ? product.name : "") + '" placeholder="เช่น ลาเต้เย็น" /></div><div class="form-field"><label for="product-category">หมวดหมู่</label><select id="product-category" name="category"><option>กาแฟ</option><option>ชา</option><option>เบเกอรี</option><option>เมล็ดกาแฟ</option></select></div><div class="form-field"><label for="product-price">ราคาขาย (บาท)</label><input id="product-price" name="price" type="number" min="1" required value="' + (product ? product.price : "") + '" placeholder="120" /></div><div class="form-field"><label for="product-cost">ต้นทุน (บาท)</label><input id="product-cost" name="cost" type="number" min="0" value="' + (product ? product.cost : "") + '" placeholder="35" /></div><div class="form-field"><label for="product-stock">จำนวนคงเหลือ</label><input id="product-stock" name="stock" type="number" min="0" value="' + (product ? product.stock : "0") + '" /></div><input type="hidden" name="id" value="' + escapeHtml(product ? product.id : "") + '"></div><div class="modal-actions"><button class="button" type="button" data-action="close-modal">ยกเลิก</button><button class="button button-primary" type="submit">' + (editing ? "บันทึกการแก้ไข" : "เพิ่มสินค้า") + "</button></div></form>");
    if (product) document.getElementById("product-category").value = product.category;
  }

  function stockInForm(item) {
    const options = inventory.map(function (entry) { return '<option value="' + entry.id + '" ' + (item && item.id === entry.id ? "selected" : "") + ">" + escapeHtml(entry.name) + " · คงเหลือ " + entry.stock + " " + entry.unit + "</option>"; }).join("");
    showModal("รับวัตถุดิบเข้าสต็อก", "อัปเดตจำนวนคงเหลือสำหรับสาขานิมมาน", '<form id="stock-form"><div class="form-grid"><div class="form-field full"><label for="stock-item">เลือกวัตถุดิบ</label><select id="stock-item" name="id">' + options + '</select></div><div class="form-field"><label for="stock-quantity">จำนวนที่รับเข้า</label><input id="stock-quantity" name="quantity" type="number" min="1" value="1" required /></div><div class="form-field"><label for="stock-reference">บันทึก / เลขที่ใบส่งของ</label><input id="stock-reference" name="reference" placeholder="ไม่บังคับ" /></div></div><div class="modal-actions"><button class="button" type="button" data-action="close-modal">ยกเลิก</button><button class="button button-primary" type="submit">บันทึกรับเข้า</button></div></form>');
  }

  function addCustomerForm() {
    showModal("เพิ่มสมาชิกใหม่", "ข้อมูลตัวอย่าง ไม่ได้ส่งออกจากเบราว์เซอร์นี้", '<form id="customer-form"><div class="form-grid"><div class="form-field full"><label for="customer-name">ชื่อและนามสกุล</label><input id="customer-name" name="name" required maxlength="60" placeholder="ชื่อสมาชิก" /></div><div class="form-field full"><label for="customer-phone">เบอร์โทรศัพท์</label><input id="customer-phone" name="phone" inputmode="tel" placeholder="08x-xxx-xxxx" /></div></div><div class="modal-actions"><button class="button" type="button" data-action="close-modal">ยกเลิก</button><button class="button button-primary" type="submit">เพิ่มสมาชิก</button></div></form>');
  }

  function addTeamForm() {
    showModal("เพิ่มทีมงาน", "ตั้งค่าข้อมูลพนักงานในสาขานี้", '<form id="team-form"><div class="form-grid"><div class="form-field full"><label for="team-name">ชื่อและนามสกุล</label><input id="team-name" name="name" required maxlength="60" /></div><div class="form-field"><label for="team-role">ตำแหน่ง</label><select id="team-role" name="role"><option>บาริสต้า</option><option>หัวหน้าบาริสต้า</option><option>ครัวและเบเกอรี</option><option>ผู้จัดการร้าน</option></select></div><div class="form-field"><label for="team-shift">กะทำงาน</label><select id="team-shift" name="shift"><option>เปิดร้าน · 07:00–15:00</option><option>กลางวัน · 10:00–18:00</option><option>ปิดร้าน · 14:30–22:00</option></select></div></div><div class="modal-actions"><button class="button" type="button" data-action="close-modal">ยกเลิก</button><button class="button button-primary" type="submit">เพิ่มทีมงาน</button></div></form>');
  }

  function refreshView() {
    render();
  }

  function addToCart(name, price) {
    const item = cart.get(name) || { name: name, price: Number(price), quantity: 0 };
    item.quantity += 1;
    cart.set(name, item);
    render();
    showToast("เพิ่ม " + name + " ลงในบิลแล้ว");
  }

  function handleAction(target) {
    const action = target.dataset.action;
    if (!action) return;
    if (action === "chart-range") { state.chartRange = target.dataset.range; refreshView(); }
    else if (action === "order-filter") { state.orderFilter = target.dataset.filter; refreshView(); }
    else if (action === "product-filter") { state.productFilter = target.dataset.filter; refreshView(); }
    else if (action === "inventory-filter") { state.inventoryFilter = target.dataset.filter; refreshView(); }
    else if (action === "go-pos") { state.page = "pos"; refreshView(); }
    else if (action === "add-product") productForm();
    else if (action === "edit-product") productForm(products.find(function (item) { return item.id === target.dataset.id; }));
    else if (action === "stock-in") stockInForm();
    else if (action === "stock-in-one") stockInForm(inventory.find(function (item) { return item.id === target.dataset.id; }));
    else if (action === "stock-adjust") {
      const item = inventory.find(function (entry) { return entry.id === target.dataset.id; });
      if (!item) return;
      item.stock = Math.max(0, item.stock + Number(target.dataset.delta));
      item.status = item.stock === 0 ? "หมด" : item.stock < item.par ? "ใกล้หมด" : "ปกติ";
      refreshView();
      showToast("ปรับจำนวน " + item.name + " แล้ว");
    }
    else if (action === "order-detail") orderDetail(target.dataset.id);
    else if (action === "pos-category") { posState.category = target.dataset.category; refreshView(); }
    else if (action === "pos-add") addToCart(target.dataset.name, target.dataset.price);
    else if (action === "pos-quantity") {
      const item = cart.get(target.dataset.id);
      if (!item) return;
      item.quantity += Number(target.dataset.delta);
      if (item.quantity <= 0) cart.delete(target.dataset.id);
      refreshView();
    }
    else if (action === "payment-method") { posState.payment = target.dataset.method; refreshView(); }
    else if (action === "checkout") checkout();
    else if (action === "add-customer") addCustomerForm();
    else if (action === "add-team") addTeamForm();
    else if (action === "edit-team") showToast("เปิดหน้าจัดการสิทธิ์ตัวอย่างแล้ว");
    else if (action === "settings-tab") { state.settingsTab = target.dataset.tab; refreshView(); }
    else if (action === "toggle-setting") {
      const key = target.dataset.key;
      state.settings[key] = !state.settings[key];
      refreshView();
      showToast("บันทึกการตั้งค่าแล้ว");
    }
    else if (action === "save-settings") showToast("บันทึกข้อมูลร้านตัวอย่างแล้ว");
    else if (action === "export") showToast("เตรียมไฟล์ตัวอย่างให้แล้ว — ระบบนี้ยังไม่เชื่อมต่อข้อมูลจริง");
    else if (action === "close-modal") closeModal();
  }

  function checkout() {
    if (!cart.size) {
      showToast("เพิ่มเมนูลงในบิลก่อนรับชำระ", "error");
      return;
    }
    let total = 0;
    let items = [];
    cart.forEach(function (item) { total += item.price * item.quantity; items.push(item.name + " × " + item.quantity); });
    const id = "BM-" + String(2049 + orders.length - 7).padStart(4, "0");
    orders.unshift({ id: id, customer: posState.customer, items: items.join(", "), time: new Date().toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" }), total: total, channel: "หน้าร้าน", status: "เสร็จแล้ว" });
    cart.clear();
    posState.customer = "ลูกค้าทั่วไป";
    state.page = "overview";
    refreshView();
    showToast("รับชำระ " + money(total) + " แล้ว · สร้างบิล #" + id);
  }

  nav.addEventListener("click", function (event) {
    const button = event.target.closest("[data-page]");
    if (!button) return;
    state.page = button.dataset.page;
    state.globalQuery = "";
    document.getElementById("global-search").value = "";
    closeSidebar();
    render();
  });

  document.addEventListener("click", function (event) {
    const pageButton = event.target.closest("[data-page]");
    if (pageButton && !nav.contains(pageButton)) {
      state.page = pageButton.dataset.page;
      state.globalQuery = "";
      document.getElementById("global-search").value = "";
      closeSidebar();
      render();
      return;
    }
    const actionTarget = event.target.closest("[data-action]");
    if (actionTarget) handleAction(actionTarget);

    if (event.target === modalLayer) closeModal();
    const popover = document.getElementById("notification-popover");
    if (!event.target.closest("#notifications-button") && !event.target.closest("#notification-popover")) {
      popover.hidden = true;
      document.getElementById("notifications-button").setAttribute("aria-expanded", "false");
    }
  });

  document.addEventListener("submit", function (event) {
    event.preventDefault();
    const form = event.target;
    const formId = form.getAttribute("id");
    const data = new FormData(form);
    if (formId === "order-status-form") {
      const order = findOrder(String(data.get("id")));
      if (order) order.status = String(data.get("status"));
      closeModal();
      render();
      showToast("อัปเดตสถานะคำสั่งซื้อแล้ว");
    } else if (formId === "product-form") {
      const id = String(data.get("id"));
      const product = products.find(function (item) { return item.id === id; });
      const name = String(data.get("name")).trim();
      const price = Number(data.get("price"));
      if (!name || price <= 0) { showToast("กรอกชื่อและราคาสินค้าให้ถูกต้อง", "error"); return; }
      if (product) {
        product.name = name;
        product.category = String(data.get("category"));
        product.price = price;
        product.cost = Number(data.get("cost")) || 0;
        product.stock = Number(data.get("stock")) || 0;
      } else {
        products.unshift({ id: "P-" + String(Date.now()).slice(-4), name: name, category: String(data.get("category")), price: price, cost: Number(data.get("cost")) || 0, stock: Number(data.get("stock")) || 0, unit: "รายการ", status: "พร้อมขาย", emoji: "☕", art: "art-green", description: "สินค้าใหม่ · เพิ่มรายละเอียดได้ภายหลัง" });
      }
      closeModal();
      render();
      showToast(product ? "บันทึกการแก้ไขสินค้าแล้ว" : "เพิ่ม " + name + " ในเมนูแล้ว");
    } else if (formId === "stock-form") {
      const item = inventory.find(function (entry) { return entry.id === String(data.get("id")); });
      if (item) {
        const quantity = Number(data.get("quantity"));
        if (quantity <= 0) { showToast("จำนวนที่รับเข้าต้องมากกว่า 0", "error"); return; }
        item.stock += quantity;
        item.status = item.stock < item.par ? "ใกล้หมด" : "ปกติ";
      }
      closeModal();
      render();
      showToast("บันทึกรับวัตถุดิบเข้าสต็อกแล้ว");
    } else if (formId === "customer-form") {
      const name = String(data.get("name")).trim();
      if (!name) return;
      customers.unshift({ name: name, phone: String(data.get("phone") || "ยังไม่ระบุ"), visits: 0, spent: 0, points: 0, last: "สมาชิกใหม่", level: "สมาชิกใหม่", initials: name.charAt(0), avatar: "" });
      closeModal();
      render();
      showToast("เพิ่ม " + name + " เป็นสมาชิกแล้ว");
    } else if (formId === "team-form") {
      const name = String(data.get("name")).trim();
      if (!name) return;
      team.push({ name: name, role: String(data.get("role")), shift: String(data.get("shift")), status: "กำลังทำงาน", initials: name.charAt(0), avatar: "avatar-4" });
      closeModal();
      render();
      showToast("เพิ่ม " + name + " ในทีมแล้ว");
    }
  });

  document.getElementById("global-search").addEventListener("input", function (event) {
    state.globalQuery = event.target.value;
    applyGlobalSearch();
  });
  document.getElementById("global-search").addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      const first = root.querySelector("[data-search]:not([hidden])");
      if (!first && state.globalQuery) showToast("ไม่พบรายการที่ตรงกับคำค้นหา", "error");
    }
  });
  document.addEventListener("keydown", function (event) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
      event.preventDefault();
      document.getElementById("global-search").focus();
    }
    const activeElement = event.target;
    const isEditing = activeElement instanceof HTMLElement &&
      (activeElement.isContentEditable || activeElement.matches("input, textarea, select"));
    if (event.key === "F2" && modalLayer.hidden && !isEditing) {
      event.preventDefault();
      state.page = "pos";
      render();
    }
    if (event.key === "Escape") {
      closeModal();
      closeSidebar();
      document.getElementById("notification-popover").hidden = true;
    }
    if (event.key === "Tab" && !modalLayer.hidden) {
      const focusable = Array.from(modalLayer.querySelectorAll("button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled)"));
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  root.addEventListener("input", function (event) {
    if (event.target.matches("[data-local-search]")) applyLocalSearch();
    if (event.target.matches("[data-pos-search]")) {
      const query = event.target.value.trim().toLowerCase();
      root.querySelectorAll(".pos-item").forEach(function (item) { item.hidden = !item.dataset.search.toLowerCase().includes(query); });
    }
  });
  root.addEventListener("change", function (event) {
    if (event.target.id === "report-range") { state.reportRange = event.target.value; render(); }
    if (event.target.id === "order-channel") { state.orderChannel = event.target.value; render(); }
    if (event.target.id === "customer-level") { state.customerLevel = event.target.value; render(); }
    if (event.target.id === "pos-customer-select") { posState.customer = event.target.value; }
  });
  document.getElementById("notifications-button").addEventListener("click", function () {
    const popover = document.getElementById("notification-popover");
    popover.hidden = !popover.hidden;
    this.setAttribute("aria-expanded", String(!popover.hidden));
  });
  document.getElementById("close-notifications").addEventListener("click", function () {
    document.getElementById("notification-popover").hidden = true;
    document.getElementById("notifications-button").setAttribute("aria-expanded", "false");
    document.getElementById("notifications-button").focus();
  });
  const sidebar = document.getElementById("sidebar");
  const scrim = document.getElementById("sidebar-scrim");
  const mobileMenu = document.getElementById("mobile-menu");
  function closeSidebar() {
    sidebar.classList.remove("is-open");
    scrim.classList.remove("is-visible");
    mobileMenu.setAttribute("aria-expanded", "false");
  }
  mobileMenu.addEventListener("click", function () {
    const open = sidebar.classList.toggle("is-open");
    scrim.classList.toggle("is-visible", open);
    this.setAttribute("aria-expanded", String(open));
  });
  scrim.addEventListener("click", closeSidebar);

  render();
}());
